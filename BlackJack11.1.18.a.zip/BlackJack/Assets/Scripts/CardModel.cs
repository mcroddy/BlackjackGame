﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardModel : MonoBehaviour
{
    SpriteRenderer spriteRenderer;
    public Sprite[] faces;
    public Sprite cardBack;

    public int cardIndex;

    public void ToggleFace(bool showFace)
    {
        if(showFace)
        {
            //show the face
            spriteRenderer.sprite = faces[cardIndex];
        }
        else
        {
            //dont show the face
            spriteRenderer.sprite = cardBack;
        }

       

    }

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();

    }

}
